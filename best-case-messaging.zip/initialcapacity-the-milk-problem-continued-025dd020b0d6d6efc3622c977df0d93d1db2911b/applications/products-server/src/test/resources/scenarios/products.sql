delete from products;

insert into products (id, name, quantity) values (105442, 'milk', 131);
insert into products (id, name, quantity) values (105443, 'bacon', 122);
insert into products (id, name, quantity) values (105444, 'tuna', 34);
insert into products (id, name, quantity) values (105445, 'eggs', 23);
insert into products (id, name, quantity) values (105446, 'kombucha', 18);
insert into products (id, name, quantity) values (105447, 'apples', 17);
insert into products (id, name, quantity) values (105448, 'ice tea', 41);
insert into products (id, name, quantity) values (105449, 'yogurt', 9);