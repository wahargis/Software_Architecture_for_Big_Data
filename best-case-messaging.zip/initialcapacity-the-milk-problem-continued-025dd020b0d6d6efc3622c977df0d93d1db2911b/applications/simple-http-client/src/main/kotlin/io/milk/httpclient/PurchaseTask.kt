package io.milk.httpclient

data class PurchaseTask(val id: Long, val name: String, val amount: Int)
