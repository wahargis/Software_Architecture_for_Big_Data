package io.milk.rabbitclient

data class PurchaseTask(val id: Long, val name: String, val amount: Int)
